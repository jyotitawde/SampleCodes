import React, { useState } from 'react';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';

const useStyles = makeStyles((theme) => ({
    root: {
        justifyContent: 'center',
        height: '100vh',
        alignItems: 'center'
    },
    button: {
        textAlign: 'center',
    },
    generateText: {
        textAlign: 'center'
    }
}));

const StringMatching = () => {
    const [text, setText] = useState('')
    const [subText, setSubText] = useState('')
    const [textActive, setTextActive] = useState(false)
    const [positions, setPositions] = useState([])

    const handleChange = (event) => {
        const element = event.target
        const value = element.value
        switch (element.name) {
            case "text":
                setText(value)
                break
            case "subText":
                setSubText(value)
                break
        }
    }

    const handleGenerate = () => {
        let positions = []
        if (subText.length < text.length) {
            for (let i = 0; i < (text.length - subText.length + 1); i++) {
                if (text.slice(i, i + subText.length) === subText) {
                    positions.push(i)
                }
            }
        }
        if (subText.length === text.length && subText === text) {
            positions.push(0)
        }
        setPositions(positions)
        setTextActive(true)
    }

    const handleClearAll = () => {
        setText('')
        setSubText('')
        setTextActive(false)
        setPositions('')
    }

    const classes = useStyles();
    return (
        <Grid container className={classes.root}>
            <Grid item xs={6} md={4}>
                <Grid container spacing={4}>
                    <Grid item xs={12}>
                        <TextField
                            fullWidth
                            label="Enter Text"
                            name="text"
                            value={text}
                            variant="outlined"
                            onChange={handleChange}
                            disabled={textActive}
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField
                            fullWidth
                            label="Enter Subtext"
                            name="subText"
                            value={subText}
                            variant="outlined"
                            onChange={handleChange}
                            disabled={textActive}
                        />
                    </Grid>
                    <Grid item xs={6} className={classes.button}>
                        <Button variant="contained" color="primary" disabled={textActive} onClick={handleGenerate}>
                            Generate Matches
                        </Button>
                    </Grid>
                    <Grid item xs={6} className={classes.button}>
                        <Button variant="outlined" color="primary" disabled={!textActive} onClick={handleClearAll}>
                            Clear All
                        </Button>
                    </Grid>
                    <Grid item xs={12}>
                        {textActive ?
                            positions !== [] ?
                                (<p className={classes.generateText}>
                                    Subtext <span style={{ fontWeight: "bold" }}>{subText}</span> appears in text <br />
                                    <span style={{ fontWeight: "bold" }}>{text}</span> at positions {positions.join(', ')}
                                </p>)
                                :
                                (<p className={classes.generateText}>
                                    No matches found
                                </p>)

                            :

                            ''
                        }
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    );
}

export
    default StringMatching;