import React from 'react';
import StringMatching from './components/StringMatching'

function App() {
  return (
    <StringMatching />
  );
}

export default App;
